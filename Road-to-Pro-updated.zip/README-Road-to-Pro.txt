ROAD TO PRO — UPDATED WEBSITE

Files
- index.html: updated single-file website. Upload this file to the root of your GitHub Pages repository to publish it.

New features
- Global search across academy cards.
- State, age-group, and pathway filters.
- Browser-local favorites.
- Interactive map of selected academy hubs (Leaflet + OpenStreetMap; internet connection required).
- Tryout schedule now supports date fields, official source URLs, and a user-managed verification status.
- Updated modern responsive styling and improved tab navigation.
- Existing academy directory, custom academy entries, coach contacts, and email template remain in place.

Important accuracy note
Tryout dates, roster openings, club contacts, and league membership change frequently. This static GitHub Pages site cannot automatically verify live tryout information. The schedule asks users to add an official source URL before marking a date as checked; only mark dates after confirming them on the club's official website. The map is a starter set of selected hubs, not a complete directory.

Privacy/storage
Favorites, custom academy entries, coach contacts, and schedule entries are stored in the visitor's own browser using localStorage. They are not shared between visitors or devices.

Publishing
1. Open your GitHub repository for Road-to-pro.
2. Replace the repository's index.html with this updated index.html.
3. Commit the change and wait for GitHub Pages to rebuild.
